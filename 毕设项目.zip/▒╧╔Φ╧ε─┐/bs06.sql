/*
Navicat MySQL Data Transfer

Source Server         : host
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : bs06

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2020-05-24 16:08:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('1', 'zs', '$2a$10$mkvTvRnm.IHMsIo3M4QX9uWzmcbstB2ylTnfa94SXBghWGMBtZ48u');
INSERT INTO `admin` VALUES ('2', 'ls', '$2a$10$sru8XXkf9BQ2MnoRtVmNO.3j9JM/7ySkpkXgJcYvr7AitiiaA7xra');

-- ----------------------------
-- Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `teacherid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `qqq` (`teacherid`),
  CONSTRAINT `qqq` FOREIGN KEY (`teacherid`) REFERENCES `teacher` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES ('6', '高等数学', '数学类', '4');
INSERT INTO `course` VALUES ('7', '大学英语', '英语', '4');
INSERT INTO `course` VALUES ('10', '游泳课', '体育', '1');
INSERT INTO `course` VALUES ('11', 'C语言程序设计', '计算机', '6');
INSERT INTO `course` VALUES ('12', '计算机网络', '计算机', '7');
INSERT INTO `course` VALUES ('13', '大学英语三', '英语', '7');

-- ----------------------------
-- Table structure for courseandstudent
-- ----------------------------
DROP TABLE IF EXISTS `courseandstudent`;
CREATE TABLE `courseandstudent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `studentid` int(11) DEFAULT NULL,
  `courseid` int(11) DEFAULT NULL,
  `part1` int(255) DEFAULT NULL,
  `part2` int(255) DEFAULT NULL,
  `part3` int(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `csacsa` (`studentid`),
  KEY `ccsc` (`courseid`),
  CONSTRAINT `ccsc` FOREIGN KEY (`courseid`) REFERENCES `course` (`id`),
  CONSTRAINT `csacsa` FOREIGN KEY (`studentid`) REFERENCES `student` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of courseandstudent
-- ----------------------------
INSERT INTO `courseandstudent` VALUES ('12', '4', '6', null, null, null);
INSERT INTO `courseandstudent` VALUES ('13', '4', '7', null, null, null);
INSERT INTO `courseandstudent` VALUES ('37', '1', '6', null, null, null);
INSERT INTO `courseandstudent` VALUES ('48', '5', '10', '88', '76', '80');
INSERT INTO `courseandstudent` VALUES ('57', '5', '6', null, null, null);
INSERT INTO `courseandstudent` VALUES ('58', '1', '7', null, null, null);
INSERT INTO `courseandstudent` VALUES ('59', '1', '10', null, null, null);
INSERT INTO `courseandstudent` VALUES ('60', '1', '11', null, null, null);

-- ----------------------------
-- Table structure for message
-- ----------------------------
DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `studentid` int(11) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `teacherid` int(11) DEFAULT NULL,
  `reply` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jjcjn` (`studentid`),
  KEY `bjbjcs` (`teacherid`),
  CONSTRAINT `bjbjcs` FOREIGN KEY (`teacherid`) REFERENCES `teacher` (`id`),
  CONSTRAINT `jjcjn` FOREIGN KEY (`studentid`) REFERENCES `student` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of message
-- ----------------------------
INSERT INTO `message` VALUES ('2', '2', 'wo shi lisi', '2020-04-30 23:17:57', '1', '好好好');
INSERT INTO `message` VALUES ('4', '1', '你好老师，能留给微信给我吗？', '2020-05-03 16:24:32', '4', '111');
INSERT INTO `message` VALUES ('5', '4', '333', '2020-05-03 21:08:20', '4', null);
INSERT INTO `message` VALUES ('6', '5', '我是学生幸世财', '2020-05-04 21:59:10', '4', null);
INSERT INTO `message` VALUES ('7', '5', '我是学生幸世财', '2020-05-04 22:25:28', '1', '收到');
INSERT INTO `message` VALUES ('8', '5', '我是幸世财第二次发消息', '2020-05-05 15:19:45', '1', null);

-- ----------------------------
-- Table structure for news
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `day` varchar(255) DEFAULT NULL,
  `month` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES ('3', '英语四级如何提高一百分？', '没有你想像的那么难哦，英语四级基本是一般人读书十几年来，再加上一些强化学习达到的水平...', '11', 'May');
INSERT INTO `news` VALUES ('4', '快速入门java，成为java大佬', '我学习java的时候，先是通读了《Java编程思想》，然后是《Java核心技术》。当时这两本书...', '10', 'May');
INSERT INTO `news` VALUES ('5', '离散数学怎么学？我来告诉你', '离散数学是现代数学的一个重要分支，是计算机科学中基础理论的核心课程...', '23', 'Jan');
INSERT INTO `news` VALUES ('6', '考研英语难吗？', '英语二的难度会低于英语一。英语二的难度在四级到六级之间,而英语一的难度在六级以上...', '31', 'jan');

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `noticeDate` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES ('1', '给我用户网站将在下午十二点进行升级', '2020-05-28');
INSERT INTO `notice` VALUES ('2', '大家多点点关注', '2020-05-21');
INSERT INTO `notice` VALUES ('3', 'hello world', '2020-05-20');

-- ----------------------------
-- Table structure for resofcourse
-- ----------------------------
DROP TABLE IF EXISTS `resofcourse`;
CREATE TABLE `resofcourse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `courseid` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `daacd` (`courseid`),
  CONSTRAINT `daacd` FOREIGN KEY (`courseid`) REFERENCES `course` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of resofcourse
-- ----------------------------
INSERT INTO `resofcourse` VALUES ('6', 'd86b69ba-d51d-4a24-9982-348c7948c66c.txt', '计算机网络资料.txt', '12', '2020-05-05 20:07:28');
INSERT INTO `resofcourse` VALUES ('7', '2c6edc34-4512-4cd1-9628-ac52f946680d.txt', 'C语言程序设计资料.txt', '11', '2020-05-05 20:22:48');
INSERT INTO `resofcourse` VALUES ('10', '7374060e-2a01-4709-8131-3215e815c2aa.txt', '课程资料.txt', '10', '2020-05-07 21:47:35');

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `tel` bigint(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1', 'zs', '$2a$10$mkvTvRnm.IHMsIo3M4QX9uWzmcbstB2ylTnfa94SXBghWGMBtZ48u', '男', '2020-04-02 00:00:00', '123455');
INSERT INTO `student` VALUES ('2', 'ls', '$2a$10$bQop81k4bXzYlo7Oug5Q.e3RPHffQRk2lRo5cRvQIcQai/.f4gWae', 'nan', '2020-05-09 00:00:00', '2324343');
INSERT INTO `student` VALUES ('3', 'ww', '$2a$10$Z1edWabAUqrtmXWIAWVK5..fbVancqqEdqDkGMK0r/xeo017VtFRe', '女', '2020-05-03 16:44:01', '5463546353');
INSERT INTO `student` VALUES ('4', 'txf', '$2a$10$jrHCgZ0QmBk2kOmTB4VTcetLymdm1IXxMSSLi0uQY1o72y5rlfLCK', '男', '2020-05-03 00:00:00', '132424');
INSERT INTO `student` VALUES ('5', '幸世财', '$2a$10$NMJApd5wANRnxDnahImfw.dtxEYwS9C9eSELecLDarfRO.JTxxbbG', '男', '2007-05-04 00:00:00', '12345');
INSERT INTO `student` VALUES ('6', '刘钊', '$2a$10$bHZOJpMUROLU1LCza0XZ3OEmjLl9GvXlzm4YyIjNVl.RTFqlDSDAm', '男', '2020-05-08 00:00:00', '12345');

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `tel` bigint(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES ('1', 'zs', '$2a$10$mkvTvRnm.IHMsIo3M4QX9uWzmcbstB2ylTnfa94SXBghWGMBtZ48u', '男', '2020-04-08 00:00:00', '4567778');
INSERT INTO `teacher` VALUES ('4', '唐先锋', '$2a$10$D4ohVWpKKa5q.K7F8SAS2enaQnG.dYoWHgnbrvxd8.Lkp62MPCozq', '男', '2013-05-03 00:00:00', '13036719767');
INSERT INTO `teacher` VALUES ('6', '夏飞', '$2a$10$Ys2kDU4RYig1QRrln/kWVuCJAoAODOnXTUywIfzwCp4hviJ7mT8v2', '男', '2020-05-05 00:00:00', '34567');
INSERT INTO `teacher` VALUES ('7', '王渝老师', '$2a$10$D9VRyW2dW1B0ZGZ4wtKTEOASWPfEBH2g/hZD6xE0eycyJ7FTOnkYm', '男', '1998-05-14 00:00:00', '13056789435');

-- ----------------------------
-- Table structure for work
-- ----------------------------
DROP TABLE IF EXISTS `work`;
CREATE TABLE `work` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `courseandstudentid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `axacs` (`courseandstudentid`),
  CONSTRAINT `axacs` FOREIGN KEY (`courseandstudentid`) REFERENCES `courseandstudent` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of work
-- ----------------------------
INSERT INTO `work` VALUES ('11', 'e107098a-c55c-4df9-a165-70a4f57baf27.txt', '体育课资料.txt', '2020-05-07 21:25:00', '59');
