package com.yc.beans;

public class Courseandstudent {
    private Integer id;

    @Override
    public String toString() {
        return "Courseandstudent{" +
                "id=" + id +
                ", studentid=" + studentid +
                ", courseid=" + courseid +
                ", part1=" + part1 +
                ", part2=" + part2 +
                ", part3=" + part3 +
                '}';
    }

    private Integer studentid;

    private Integer courseid;

    private Integer part1;

    private Integer part2;

    private Integer part3;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getStudentid() {
        return studentid;
    }

    public void setStudentid(Integer studentid) {
        this.studentid = studentid;
    }

    public Integer getCourseid() {
        return courseid;
    }

    public void setCourseid(Integer courseid) {
        this.courseid = courseid;
    }

    public Integer getPart1() {
        return part1;
    }

    public void setPart1(Integer part1) {
        this.part1 = part1;
    }

    public Integer getPart2() {
        return part2;
    }

    public void setPart2(Integer part2) {
        this.part2 = part2;
    }

    public Integer getPart3() {
        return part3;
    }

    public void setPart3(Integer part3) {
        this.part3 = part3;
    }
}