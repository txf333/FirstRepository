package com.yc.beans;

import java.util.Date;

public class Work {
    private Integer id;

    private String path;

    private String name;

    private Date date;

    private Integer courseandstudentid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path == null ? null : path.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Integer getCourseandstudentid() {
        return courseandstudentid;
    }

    public void setCourseandstudentid(Integer courseandstudentid) {
        this.courseandstudentid = courseandstudentid;
    }
}