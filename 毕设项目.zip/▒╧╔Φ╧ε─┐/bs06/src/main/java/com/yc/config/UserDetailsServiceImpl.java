package com.yc.config;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import com.yc.beans.News;
import com.yc.beans.Teacher;
import com.yc.service.NewsService;
import com.yc.service.StudentService;
import com.yc.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import com.yc.beans.Admin;
import com.yc.beans.Student;
import com.yc.service.AdminService;
@Component
public class UserDetailsServiceImpl implements UserDetailsService{
	@Autowired(required=false)
	private BCryptPasswordEncoder passwordEncoder;
	@Autowired
	private HttpServletRequest request;
	@Autowired
	private StudentService studentService;
	@Autowired
	private TeacherService teacherService;
	@Autowired
	private AdminService adminService;
	@Autowired
	private NewsService newsService;
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	    username=username.trim();
		String password = request.getParameter("password").trim();
		String type = request.getParameter("type").trim();
		
		if (username.trim().equals("")||password.trim().equals("")) {
			System.out.println("请输入用户名和密码");
			throw new BadCredentialsException("请输入用户名和密码");
		}
		String dbPassword = findPasswordByUsernameAndType(username,type);
		if (dbPassword==null) {
			System.out.println("帐号不存在，请重新输入");
			throw new BadCredentialsException("帐号不存在，请重新输入");
		}
		if (passwordEncoder!=null) {
			if (!passwordEncoder.matches(password, dbPassword)) {
				System.out.println("密码错误，请重新输入");
				throw new BadCredentialsException("密码错误，请重新输入");
			}
		}else {
			if (!password.equals(dbPassword)) {
				System.out.println("密码错误，请重新输入");
				throw new BadCredentialsException("密码错误，请重新输入");
			}
		}
		
		
		List<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>();
		authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
//		List<Role> roles=null;
//		for (Role role : roles) {
//			authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
//		}
		UserDetails userDetails = new org.springframework.security.core.userdetails.User(username,
				dbPassword, authorities);
		return userDetails;
	}
	private String findPasswordByUsernameAndType(String username, String type) {
		// TODO Auto-generated method stub
		if(type.equals("student")) {
			List<Student> list = studentService.findAll();
			for (Student Student : list) {
				if (Student.getUsername().equals(username)) {
					request.getSession().setAttribute("student", Student);
					List<News> all = newsService.findAll();
					request.getSession().setAttribute("newList",all);
					return Student.getPassword();
				}
			}
		}else if (type.equals("admin")) {
			List<Admin> list = adminService.findAll();
			for (Admin admin : list) {
				if (admin.getUsername().equals(username)) {
					request.getSession().setAttribute("admin", admin);
					List<News> all = newsService.findAll();
					request.getSession().setAttribute("newList",all);
					return admin.getPassword();
				}
			}
		}else if (type.equals("teacher")) {
			List<Teacher> list = teacherService.findAll();
			for (Teacher teacher : list) {
				if (teacher.getUsername().equals(username)) {
					request.getSession().setAttribute("teacher", teacher);
					List<News> all = newsService.findAll();
					request.getSession().setAttribute("newList",all);
					return teacher.getPassword();
				}
			}
		}
		return null;
	}
}
