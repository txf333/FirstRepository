package com.yc.controller;

import java.util.Iterator;
import java.util.List;

import com.yc.beans.Courseandstudent;
import com.yc.beans.Student;
import com.yc.service.CourseService;
import com.yc.service.CourseandstudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.yc.beans.Admin;
import com.yc.service.AdminService;

import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    BCryptPasswordEncoder encoder;
    @Autowired
    private AdminService adminService;
    @Autowired
    private CourseandstudentService courseandstudentService;
    @Autowired
    private CourseService courseService;
    @RequestMapping("/findAll")
    public String findAll(Model model, HttpSession session) {
        Student student = (Student) session.getAttribute("student");
        List<Courseandstudent> courseandstudents = courseandstudentService.findAllByStudent(student.getId());
        List<Admin> list = adminService.findAll();
        A:for (Iterator<Admin> iterator = list.iterator(); iterator.hasNext(); ) {
            Admin admin =  iterator.next();
            for (Courseandstudent courseandstudent : courseandstudents) {
                if (admin.getId().equals(courseService.findById(courseandstudent.getCourseid()).getId())){
                    continue A;
                }
            }
            iterator.remove();
        }
        model.addAttribute("list", list);
        return "/page/admin/adminItem.jsp";
    }
    /*@RequestMapping("/findAll")
    public String findAll(Model model) {
        List<Admin> list = adminService.findAll();
        model.addAttribute("list", list);
        return "/page/admin/adminItem.jsp";
    }*/

    @RequestMapping("/saveById")
    public String saveById(Model model, Integer id) {
        model.addAttribute("adminid", id);
        return "/page/admin/send.jsp";
    }

    @RequestMapping("/deleteById")
    public String deleteById(Integer id) {
        adminService.deleteById(id);
        return "findAll";
    }

    @RequestMapping("/updateById")
    public String updateById(Admin admin) {
        adminService.updateById(admin);
        return "findAll";
    }

    @RequestMapping("/insert")
    public String insert(Admin admin) {
        admin.setPassword(encoder.encode(admin.getPassword()));
        adminService.insertById(admin);
        return "/login.jsp";
    }
}