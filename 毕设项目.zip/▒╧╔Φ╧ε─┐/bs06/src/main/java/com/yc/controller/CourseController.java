package com.yc.controller;

import java.util.Iterator;
import java.util.List;

import com.yc.beans.*;
import com.yc.service.CourseandstudentService;
import com.yc.service.ResofcourseService;
import com.yc.service.WorkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.yc.service.CourseService;

import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/course")
public class CourseController {

    @Autowired
    private CourseService courseService;
    @Autowired
    ResofcourseService resofcourseService;
    @Autowired
    CourseandstudentService courseandstudentService;
    @Autowired
    WorkService workService;

    @RequestMapping("/findAll")
    public String findAll(Model model,HttpSession session) {
        Student student = (Student) session.getAttribute("student");
        Teacher teacher = (Teacher) session.getAttribute("teacher");

        System.out.println(student);
        List<Course> list;
        if (student!=null){
            list=courseService.findAll(student);
        }else {
            list = courseService.findAll();
            for (Iterator<Course> iterator = list.iterator(); iterator.hasNext(); ) {
                Course course =  iterator.next();
                if (!course.getTeacherid().equals(teacher.getId())){
                    iterator.remove();
                }
            }
        }
        model.addAttribute("list", list);
        return "/page/course/courseItem.jsp";
    }

    @RequestMapping("/saveById")
    public String saveById(Model model, Integer id) {
        Course course = courseService.findById(id);
        model.addAttribute("course", course);
        return "/page/course/courseUpdate.jsp";
    }

    @RequestMapping("/deleteById")
    public String deleteById(Integer id) {

        for (Resofcourse resofcourse : resofcourseService.findAll()) {
            if (resofcourse.getCourseid().equals(id)){
                resofcourseService.deleteById(resofcourse.getId());
            }
        }
        CourseandstudentExample ex=new CourseandstudentExample();
        ex.createCriteria().andCourseidEqualTo(id);
        for (Courseandstudent courseandstudent : courseandstudentService.findAll(ex)) {
            for (Work work : workService.findAll()) {
                if (work.getCourseandstudentid().equals(courseandstudent.getId())){
                    workService.deleteById(work.getId());
                }
            }
            courseandstudentService.deleteById(courseandstudent.getId());
        }
        courseService.deleteById(id);
        return "findAll";
    }

    @RequestMapping("/updateById")
    public String updateById(Course course) {
        courseService.updateById(course);
        return "findAll";
    }

    @RequestMapping("/insert")
    public String insert(Course course,HttpSession session) {
        Teacher teacher = (Teacher) session.getAttribute("teacher");
        course.setTeacherid(teacher.getId());
        courseService.insertById(course);
        return "findAll";
    }
}