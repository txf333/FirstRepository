package com.yc.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.yc.beans.*;
import com.yc.custom.TeacherCourse;
import com.yc.service.CourseService;
import com.yc.service.StudentService;
import com.yc.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.yc.service.CourseandstudentService;

import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/courseandstudent")
public class CourseandstudentController {

    @Autowired
    private CourseandstudentService courseandstudentService;

    @Autowired
    private CourseService courseService;
    @Autowired
    private TeacherService teacherService;
    @Autowired
    private StudentService studentService;

    @RequestMapping("/findAll")
    public String findAll(Model model,HttpSession session) {
        List<Courseandstudent> list;
        Student student = (Student) session.getAttribute("student");
        Teacher teacher = (Teacher) session.getAttribute("teacher");
        if (student!=null){
            CourseandstudentExample example = new CourseandstudentExample();
            example.createCriteria().andStudentidEqualTo(student.getId());
            list = courseandstudentService.findAll(example);
        }else {
            list=courseandstudentService.findAll(null);
            for (Iterator<Courseandstudent> iterator = list.iterator(); iterator.hasNext(); ) {
                Courseandstudent courseandstudent =  iterator.next();
                if (!courseService.findById(courseandstudent.getCourseid()).getTeacherid().equals(teacher.getId())){
                    iterator.remove();
                }
            }
        }
        ArrayList<TeacherCourse> teacherCourses = new ArrayList<>();
        for (Courseandstudent courseandstudent : list) {
            TeacherCourse teacherCourse = new TeacherCourse();
            Course course = courseService.findById(courseandstudent.getCourseid());
            teacherCourse.setCourse(course);
            teacherCourse.setTeacher(teacherService.findById(course.getTeacherid()));
            teacherCourse.setStudent(studentService.findById(courseandstudent.getStudentid()));
            teacherCourse.setCourseandstudent(courseandstudent);
            teacherCourses.add(teacherCourse);
        }

        for (TeacherCourse teacherCours : teacherCourses) {
            System.out.println(teacherCours);
        }
        model.addAttribute("list", teacherCourses);
        return "/page/courseandstudent/courseandstudentItem.jsp";
    }

    @RequestMapping("/saveById")
    public String saveById(Model model, Integer id) {
        Courseandstudent courseandstudent = courseandstudentService.findById(id);
        model.addAttribute("courseandstudent", courseandstudent);
        return "/page/courseandstudent/courseandstudentUpdate.jsp";
    }

    @RequestMapping("/deleteById")
    public String deleteById(Integer id) {
        courseandstudentService.deleteById(id);
        return "findAll";
    }

    @RequestMapping("/updateById")
    public String updateById(Courseandstudent courseandstudent) {
        courseandstudentService.updateById(courseandstudent);
        return "findAll";
    }

    @RequestMapping("/insert")
    public String insert(Courseandstudent courseandstudent, HttpSession session) {
        Student student = (Student) session.getAttribute("student");
        courseandstudent.setStudentid(student.getId());
        courseandstudentService.insertById(courseandstudent);
        return "findAll";
    }
}