package com.yc.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {
	@RequestMapping("/register")
	public String register(String type,String username,String password,Model model) {
		if (username.equals("")||password.equals("")){
            model.addAttribute("msg","用户名或密码不能为空！");
            return "/register.jsp";
        }
		switch (type) {
			case "student":
				return "/student/insert";
			case "teacher":
				return "/teacher/insert";
			case "admin":
				return "/admin/insert";
		}
		return null;
	}

}
