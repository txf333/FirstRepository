package com.yc.controller;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.yc.beans.Student;
import com.yc.beans.Teacher;
import com.yc.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.yc.beans.Message;
import com.yc.service.MessageService;

import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/message")
public class MessageController {

    @Autowired
    private MessageService messageService;

    @Autowired
    private StudentService studentService;

    @RequestMapping("/findAll")
    public String findAll(Model model,HttpSession session,Integer teacherid) {
        List<Message> list = messageService.findAll();
        System.out.println(teacherid+"...................");
        if (teacherid!=null){
            Student student = (Student) session.getAttribute("student");
            for (Iterator<Message> iterator = list.iterator(); iterator.hasNext(); ) {
                Message message = iterator.next();
                if (!message.getTeacherid().equals(teacherid)||!message.getStudentid().equals(student.getId())){
                    iterator.remove();
                }else{
                    Integer studentid = message.getStudentid();
                    Student byId = studentService.findById(studentid);
                    message.setSname(byId.getUsername());
                }
            }
        }else {
            Teacher teacher = (Teacher) session.getAttribute("teacher");
            System.out.println(teacher+"...................");
            for (Iterator<Message> iterator = list.iterator(); iterator.hasNext(); ) {
                Message message = iterator.next();
                if (!message.getTeacherid().equals(teacher.getId())){
                    iterator.remove();
                }else{
                    Integer studentid = message.getStudentid();
                    Student byId = studentService.findById(studentid);
                    message.setSname(byId.getUsername());
                }
            }
        }



        model.addAttribute("list", list);
        return "/page/message/messageItem.jsp";
    }

    @RequestMapping("/saveById")
    public String saveById(Model model, Integer id) {
        model.addAttribute("id", id);
        return "/page/message/reply.jsp";
    }

    @RequestMapping("/deleteById")
    public String deleteById(Integer id) {
        messageService.deleteById(id);
        return "findAll";
    }

    @RequestMapping("/updateById")
    public String updateById(Message message) {
        Message message1 = messageService.findById(message.getId());
        message1.setReply(message.getReply());
        messageService.updateById(message1);
        return "findAll";
    }

    @RequestMapping("/insert")
    public String insert(Message message, HttpSession session) {
        Student student = (Student) session.getAttribute("student");
        message.setStudentid(student.getId());
        message.setDate(new Date());
        messageService.insertById(message);
        return "findAll?teacherid="+message.getTeacherid();
    }
}