package com.yc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import com.yc.beans.News;
import com.yc.service.NewsService;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/news")
public class NewsController {

    @Autowired
    private NewsService newsService;

    @RequestMapping("/findAll")
    public String findAll(Model model) {
        List<News> list = newsService.findAll();
        model.addAttribute("list", list);
        return "/page/news/newsItem.jsp";
    }

    @RequestMapping("/saveById")
    public String saveById(Model model, Integer id) {
        News news = newsService.findById(id);
        model.addAttribute("news", news);
        return "/page/news/newsUpdate.jsp";
    }

    @RequestMapping("/deleteById")
    public String deleteById(Integer id) {
        newsService.deleteById(id);
        return "findAll";
    }

    @RequestMapping("/updateById")
    public String updateById(News news) {
        newsService.updateById(news);
        return "findAll";
    }

    @RequestMapping("/insert")
    public String insert(News news) {
        newsService.insertById(news);
        return "findAll";
    }

    @RequestMapping("/queryNewByID")
    public String queryNewByID(Model model,@RequestParam("id") Integer id) {
        News news = newsService.findById(id);
        model.addAttribute("news", news);
        return "/page/news/showdetail.jsp";
    }
}