package com.yc.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.yc.beans.Notice;
import com.yc.service.NoticeService;

@Controller
@RequestMapping("/notice")
public class NoticeController {

    @Autowired
    private NoticeService noticeService;

    @RequestMapping("/findAll")
    public String findAll(Model model) {
        List<Notice> list = noticeService.findAll();
        SimpleDateFormat sdf =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss" );
        for(Notice notice : list) {
            Date noticeDate = notice.getNoticeDate();
            String str = sdf.format(noticeDate);
            notice.setTime(str);
        }
        model.addAttribute("list", list);
        return "/page/notice/noticeItem.jsp";
    }

    @RequestMapping("/saveById")
    public String saveById(Model model, Integer id) {
        Notice notice = noticeService.findById(id);
        model.addAttribute("notice", notice);
        return "/page/notice/noticeUpdate.jsp";
    }

    @RequestMapping("/deleteById")
    public String deleteById(Integer id) {
        noticeService.deleteById(id);
        return "findAll";
    }

    @RequestMapping("/updateById")
    public String updateById(Notice notice) {
        noticeService.updateById(notice);
        return "findAll";
    }

    @RequestMapping("/insert")
    public String insert(Notice notice) {
        noticeService.insertById(notice);
        return "findAll";
    }
}