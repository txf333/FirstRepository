package com.yc.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.yc.beans.Resofcourse;
import com.yc.service.ResofcourseService;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import sun.misc.BASE64Encoder;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/resofcourse")
public class ResofcourseController {

    @Autowired
    private ResofcourseService resofcourseService;

    @RequestMapping("/findAll")
    public String findAll(Model model, HttpSession session, Integer courseid) {
        List<Resofcourse> list = resofcourseService.findAll();

        for (Iterator<Resofcourse> iterator = list.iterator(); iterator.hasNext(); ) {
            Resofcourse resofcourse =  iterator.next();
            if (!resofcourse.getCourseid().equals(courseid)){
                iterator.remove();
            }
        }
        model.addAttribute("list", list);
        session.setAttribute("courseid", courseid);
        return "/page/resofcourse/resofcourseItem.jsp";
    }

    @RequestMapping("/dowload")
    public void dowload(Model model, String path,String name,HttpServletRequest request, HttpServletResponse response) throws IOException {
        String filename = request.getRealPath("/") + "\\upload\\"+path;
        String contentType = request.getServletContext().getMimeType(filename);
        response.setHeader("Content-Type", contentType);
        String contentDisposition = "attachment;filename="+filenameEncoding(name,request);
        response.setHeader("Content-Disposition", contentDisposition);

        File file = new File(filename);
        FileInputStream inputStream = new FileInputStream(file);
        ServletOutputStream outputStream = response.getOutputStream();
        byte[] bs=new byte[1024];
        int len=0;
        while ((len=inputStream.read(bs))!=-1){
            outputStream.write(bs,0,len);
        }
        inputStream.close();
    }

    public static String filenameEncoding(String filename, HttpServletRequest request) throws IOException {
        String agent = request.getHeader("User-Agent"); //获取浏览器
        if (agent.contains("Firefox")) {
            BASE64Encoder base64Encoder = new BASE64Encoder();
            filename = "=?utf-8?B?"
                    + base64Encoder.encode(filename.getBytes("utf-8"))
                    + "?=";
        } else if(agent.contains("MSIE")) {
            filename = URLEncoder.encode(filename, "utf-8");
        } else {
            filename = URLEncoder.encode(filename, "utf-8");
        }
        return filename;
    }
    @RequestMapping("/deleteById")
    public String deleteById(Integer id) {
        resofcourseService.deleteById(id);
        return "findAll";
    }

    @RequestMapping("/updateById")
    public String updateById(Resofcourse resofcourse) {
        resofcourse.setDate(new Date());
        resofcourseService.updateById(resofcourse);
        return "findAll";
    }

    @RequestMapping("/insert")
    public String insert(Resofcourse resofcourse, @RequestParam MultipartFile pic, HttpServletRequest request) throws IOException {
        String originalFilename = pic.getOriginalFilename();
        System.out.println(originalFilename+".........");
        if (pic != null && originalFilename != null
                && originalFilename.length() > 0) {

            String pic_path = request.getRealPath("/") + "\\upload";
            String newFileName = UUID.randomUUID()
                    + originalFilename.substring(originalFilename
                    .lastIndexOf("."));
            File newFile = new File(pic_path, newFileName);
            System.out.println("new File path........."
                    + newFile.getAbsolutePath());
            pic.transferTo(newFile);
            resofcourse.setPath(newFileName);
            resofcourse.setName(originalFilename);
            resofcourse.setDate(new Date());
            resofcourseService.insertById(resofcourse);
            return "findAll?courseid="+resofcourse.getCourseid();
        }else {
            return "/page/resofcourse/resofcourseInsert.jsp";
        }
    }
}