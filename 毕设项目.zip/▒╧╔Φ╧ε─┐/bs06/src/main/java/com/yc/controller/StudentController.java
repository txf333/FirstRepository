package com.yc.controller;

import java.util.Iterator;
import java.util.List;

import com.yc.beans.Courseandstudent;
import com.yc.beans.Message;
import com.yc.beans.Work;
import com.yc.service.CourseandstudentService;
import com.yc.service.MessageService;
import com.yc.service.WorkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.yc.beans.Student;
import com.yc.service.StudentService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/student")
public class StudentController {

    @Autowired
    private MessageService messageService;
    @Autowired
    private StudentService studentService;
    @Autowired
    BCryptPasswordEncoder encoder;

    @Autowired
    private WorkService workService;
    @Autowired
    private CourseandstudentService courseandstudentService;

    @RequestMapping("/findAll")
    public String findAll(Model model) {
        List<Student> list = studentService.findAll();
        model.addAttribute("list", list);
        return "/page/student/studentItem.jsp";
    }

    @RequestMapping("/saveById")
    public String saveById(Model model, Integer id) {
        Student student = studentService.findById(id);
        model.addAttribute("student", student);
        return "/page/student/studentUpdate.jsp";
    }

    @RequestMapping("/deleteById")
    public String deleteById(Integer id) {
        final List<Courseandstudent> courseandstudents = courseandstudentService.findAllByStudent(id);
        System.out.println(courseandstudents);
        for (Courseandstudent courseandstudent : courseandstudents) {
            List<Work> works = workService.findAll();
            for (Work work : works) {
                if (work.getCourseandstudentid().equals(courseandstudent.getId())){
                    workService.deleteById(work.getId());
                }
            }
            courseandstudentService.deleteById(courseandstudent.getId());
        }
        for (Message message : messageService.findAll()) {
            if (message.getStudentid().equals(id)){
                messageService.deleteById(message.getId());
            }
        }



        studentService.deleteById(id);
        return "findAll";
    }

    @RequestMapping("/updateById")
    public String updateById(Student student) {
        student.setPassword(encoder.encode(student.getPassword()));
        studentService.updateById(student);
        return "findAll";
    }

    @RequestMapping("/insert")
    public String insert(Student student, HttpServletRequest request) {
        student.setPassword(encoder.encode(student.getPassword()));
        studentService.insertById(student);
        Object admin = request.getSession().getAttribute("admin");
        if (admin==null){
            return "/login.jsp";
        }
        return "findAll";
    }
}