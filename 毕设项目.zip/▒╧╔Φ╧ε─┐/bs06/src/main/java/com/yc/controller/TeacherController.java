package com.yc.controller;

import java.util.Iterator;
import java.util.List;

import com.yc.beans.*;
import com.yc.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/teacher")
public class TeacherController {

    @Autowired
    private TeacherService teacherService;
    @Autowired
    BCryptPasswordEncoder encoder;
    @Autowired
    private CourseandstudentService courseandstudentService;
    @Autowired
    private CourseService courseService;


    @Autowired
    private MessageService messageService;
    @Autowired
    private StudentService studentService;

    @Autowired
    private WorkService workService;

    @RequestMapping("/findAll")
    public String findAll(Model model, HttpSession session) {
        List<Teacher> list;
        Student student = (Student) session.getAttribute("student");
        list= teacherService.findAll();
        if (student!=null){
            List<Courseandstudent> courseandstudents = courseandstudentService.findAllByStudent(student.getId());
            A:for (Iterator<Teacher> iterator = list.iterator(); iterator.hasNext(); ) {
                    Teacher teacher =  iterator.next();
                    for (Courseandstudent courseandstudent : courseandstudents) {
                        if (teacher.getId().equals(courseService.findById(courseandstudent.getCourseid()).getTeacherid())){
                            continue A;
                        }
                    }
                iterator.remove();
            }

        }
        model.addAttribute("list", list);
        return "/page/teacher/teacherItem.jsp";
    }

    @RequestMapping("/saveById")
    public String saveById(Model model, Integer id) {
        Teacher teacher = teacherService.findById(id);
        model.addAttribute("teacher", teacher);
        return "/page/teacher/teacherUpdate.jsp";
    }
    @RequestMapping("/send1")
    public String send1(Model model, Integer id) {
        model.addAttribute("teacherid", id);
        return "/page/message/send.jsp";
    }

    @RequestMapping("/deleteById")
    public String deleteById(Integer id) {

        for (Course course : courseService.findAllByTeacher(id)) {
            CourseandstudentExample example=new CourseandstudentExample();
            example.createCriteria().andCourseidEqualTo(course.getId());
            for (Courseandstudent courseandstudent : courseandstudentService.findAll(example)) {
                List<Work> works = workService.findAll();
                for (Work work : works) {
                    if (work.getCourseandstudentid().equals(courseandstudent.getId())){
                        workService.deleteById(work.getId());
                    }
                }
                courseandstudentService.deleteById(courseandstudent.getId());
            }
            courseService.deleteById(course.getId());
        }


        for (Message message : messageService.findAll()) {
            if (message.getTeacherid().equals(id)){
                messageService.deleteById(message.getId());
            }
        }


        teacherService.deleteById(id);
        return "findAll";
    }

    @RequestMapping("/updateById")
    public String updateById(Teacher teacher) {
        teacher.setPassword(encoder.encode(teacher.getPassword()));
        teacherService.updateById(teacher);
        return "findAll";
    }

    @RequestMapping("/insert")
    public String insert(Teacher teacher, HttpServletRequest request) {
        teacher.setPassword(encoder.encode(teacher.getPassword()));
        teacherService.insertById(teacher);
        Object admin = request.getSession().getAttribute("admin");
        if (admin==null){
            return "/login.jsp";
        }
        return "findAll";
    }
}