package com.yc.controller;

import java.io.File;
import java.io.IOException;
import java.util.*;

import com.yc.beans.*;
import com.yc.custom.WorkPlus;
import com.yc.service.CourseService;
import com.yc.service.CourseandstudentService;
import com.yc.service.StudentService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.yc.service.WorkService;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/work")
public class WorkController {
    @Autowired
    private StudentService studentService;
    @Autowired
    private WorkService workService;
    @Autowired
    private CourseandstudentService courseandstudentService;

    @Autowired
    CourseService courseService;
    @RequestMapping("/findAll")
    public String findAll(Model model, HttpSession session) {
        Student student = (Student) session.getAttribute("student");
        Teacher teacher = (Teacher) session.getAttribute("teacher");
        List<Work> list = workService.findAll();
        if (student!=null) {
            List<Courseandstudent> courseandstudents = courseandstudentService.findAllByStudent(student.getId());
            A:
            for (Iterator<Work> iterator = list.iterator(); iterator.hasNext(); ) {
                Work work = iterator.next();
                for (Courseandstudent courseandstudent : courseandstudents) {
                    if (work.getCourseandstudentid().equals(courseandstudent.getId())) {
                        continue A;
                    }
                }
                iterator.remove();
            }
            System.out.println("list............="+list);
        }else if (teacher!=null){
            List<Course> courses = courseService.findAllByTeacher(teacher.getId());
            A:for (Iterator<Work> iterator = list.iterator(); iterator.hasNext(); ) {
                Work work = iterator.next();
                Courseandstudent courseandstudent = courseandstudentService.findById(work.getCourseandstudentid());
                System.out.println(courseandstudent);
                for (Course cours : courses) {
                    if (courseandstudent.getCourseid().equals(cours.getId())){
                        continue A;
                    }
                }
                iterator.remove();
            }
        }
        ArrayList<WorkPlus> workPluses = new ArrayList<>();
        for (Work work : list) {
            WorkPlus workPlus = new WorkPlus();
            BeanUtils.copyProperties(work,workPlus);
            Courseandstudent courseandstudent = courseandstudentService.findById(work.getCourseandstudentid());
            workPlus.setCourseName(courseService.findById(courseandstudent.getCourseid()).getName());
            workPlus.setUsername(studentService.findById(courseandstudent.getStudentid()).getUsername());
            workPluses.add(workPlus);
        }
        model.addAttribute("list", workPluses);
        return "/page/work/workItem.jsp";
    }

    @RequestMapping("/saveById")
    public String saveById(Model model, Integer courseandstudentid) {
        model.addAttribute("courseandstudentid", courseandstudentid);
        return "/page/work/workInsert.jsp";
    }

    @RequestMapping("/deleteById")
    public String deleteById(Integer id) {
        workService.deleteById(id);
        return "findAll";
    }

    @RequestMapping("/updateById")
    public String updateById(Work work) {
        workService.updateById(work);
        return "findAll";
    }

    @RequestMapping("/insert")
    public String insert(Work work, @RequestParam MultipartFile pic, HttpServletRequest request) throws IOException {

        String originalFilename = pic.getOriginalFilename();
        System.out.println(originalFilename+".........");

        if (pic != null && originalFilename != null
                && originalFilename.length() > 0) {

            String pic_path = request.getRealPath("/") + "\\upload";
            String newFileName = UUID.randomUUID()
                    + originalFilename.substring(originalFilename
                    .lastIndexOf("."));
            File newFile = new File(pic_path, newFileName);
            System.out.println("new File path........."
                    + newFile.getAbsolutePath());
            pic.transferTo(newFile);
            work.setPath(newFileName);
            work.setName(originalFilename);
            work.setDate(new Date());
            workService.insertById(work);
            return "findAll";
        }else {
            return "/page/work/workItem.jsp";
        }

    }
}