package com.yc.custom;

import com.yc.beans.Course;
import com.yc.beans.Courseandstudent;
import com.yc.beans.Student;
import com.yc.beans.Teacher;

public class TeacherCourse {
    private Teacher teacher;
    private Course course;
    private Student student;
    private Courseandstudent courseandstudent;

    @Override
    public String toString() {
        return "TeacherCourse{" +
                "teacher=" + teacher +
                ", course=" + course +
                ", student=" + student +
                ", courseandstudent=" + courseandstudent +
                '}';
    }

    public Courseandstudent getCourseandstudent() {
        return courseandstudent;
    }

    public void setCourseandstudent(Courseandstudent courseandstudent) {
        this.courseandstudent = courseandstudent;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }
}
