package com.yc.mapper;

import com.yc.beans.Courseandstudent;
import com.yc.beans.CourseandstudentExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CourseandstudentMapper {
    int countByExample(CourseandstudentExample example);

    int deleteByExample(CourseandstudentExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Courseandstudent record);

    int insertSelective(Courseandstudent record);

    List<Courseandstudent> selectByExample(CourseandstudentExample example);

    Courseandstudent selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Courseandstudent record, @Param("example") CourseandstudentExample example);

    int updateByExample(@Param("record") Courseandstudent record, @Param("example") CourseandstudentExample example);

    int updateByPrimaryKeySelective(Courseandstudent record);

    int updateByPrimaryKey(Courseandstudent record);
}