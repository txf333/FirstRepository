package com.yc.mapper;

import com.yc.beans.Resofcourse;
import com.yc.beans.ResofcourseExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ResofcourseMapper {
    int countByExample(ResofcourseExample example);

    int deleteByExample(ResofcourseExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Resofcourse record);

    int insertSelective(Resofcourse record);

    List<Resofcourse> selectByExample(ResofcourseExample example);

    Resofcourse selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Resofcourse record, @Param("example") ResofcourseExample example);

    int updateByExample(@Param("record") Resofcourse record, @Param("example") ResofcourseExample example);

    int updateByPrimaryKeySelective(Resofcourse record);

    int updateByPrimaryKey(Resofcourse record);
}