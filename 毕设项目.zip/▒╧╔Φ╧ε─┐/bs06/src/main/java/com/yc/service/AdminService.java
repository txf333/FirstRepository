package com.yc.service;

import java.util.List;
import com.yc.beans.Admin;
public interface AdminService {
List<Admin> findAll();
Admin findById(Integer id);
int deleteById(Integer id);
int updateById(Admin admin);
int insertById(Admin admin);
}
