package com.yc.service;

import java.util.List;
import com.yc.beans.Course;
import com.yc.beans.Courseandstudent;
import com.yc.beans.Student;

public interface CourseService {
    public List<Course> findAllByTeacher(Integer teacherid);
    List<Course> findAll();
    Course findById(Integer id);
    int deleteById(Integer id);
    int updateById(Course course);
    int insertById(Course course);
    List<Course> findAll(Student student);
}
