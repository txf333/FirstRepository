package com.yc.service;

import java.util.List;

import com.yc.beans.Courseandstudent;
import com.yc.beans.CourseandstudentExample;

public interface CourseandstudentService {
    public List<Courseandstudent> findAllByStudent(Integer studentid);


    List<Courseandstudent> findAll(CourseandstudentExample courseandstudentExample);

    Courseandstudent findById(Integer id);

    int deleteById(Integer id);

    int updateById(Courseandstudent courseandstudent);

    int insertById(Courseandstudent courseandstudent);
}
