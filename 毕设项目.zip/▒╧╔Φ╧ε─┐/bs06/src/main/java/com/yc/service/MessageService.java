package com.yc.service;

import java.util.List;
import com.yc.beans.Message;
public interface MessageService {
List<Message> findAll();
Message findById(Integer id);
int deleteById(Integer id);
int updateById(Message message);
int insertById(Message message);
}
