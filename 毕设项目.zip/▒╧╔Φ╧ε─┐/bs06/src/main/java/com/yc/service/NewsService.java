package com.yc.service;

import java.util.List;
import com.yc.beans.News;
public interface NewsService {
List<News> findAll();
News findById(Integer id);
int deleteById(Integer id);
int updateById(News news);
int insertById(News news);
}
