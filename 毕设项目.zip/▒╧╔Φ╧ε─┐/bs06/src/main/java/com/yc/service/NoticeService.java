package com.yc.service;

import java.util.List;
import com.yc.beans.Notice;
public interface NoticeService {
List<Notice> findAll();
Notice findById(Integer id);
int deleteById(Integer id);
int updateById(Notice notice);
int insertById(Notice notice);
}
