package com.yc.service;

import java.util.List;
import com.yc.beans.Resofcourse;
public interface ResofcourseService {
List<Resofcourse> findAll();
Resofcourse findById(Integer id);
int deleteById(Integer id);
int updateById(Resofcourse resofcourse);
int insertById(Resofcourse resofcourse);
}
