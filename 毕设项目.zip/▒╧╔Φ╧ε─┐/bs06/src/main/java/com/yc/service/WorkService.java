package com.yc.service;

import java.util.List;
import com.yc.beans.Work;
public interface WorkService {
List<Work> findAll();
Work findById(Integer id);
int deleteById(Integer id);
int updateById(Work work);
int insertById(Work work);
}
