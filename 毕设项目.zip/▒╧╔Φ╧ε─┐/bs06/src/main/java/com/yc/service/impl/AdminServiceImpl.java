package com.yc.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yc.beans.Admin;
import com.yc.mapper.*;
import com.yc.service.AdminService;
@Service
public class AdminServiceImpl implements AdminService{
@Autowired
private AdminMapper adminMapper;
public List<Admin> findAll() {
return adminMapper.selectByExample(null);
}
public Admin findById(Integer id) {
return adminMapper.selectByPrimaryKey(id);
}
public int updateById(Admin admin) {
return adminMapper.updateByPrimaryKey(admin);
}
public int insertById(Admin admin) {
return adminMapper.insert(admin);
}
public int deleteById(Integer id) {
return adminMapper.deleteByPrimaryKey(id);
}
}
