package com.yc.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.yc.beans.*;
import com.yc.service.CourseandstudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yc.mapper.*;
import com.yc.service.CourseService;

@Service
public class CourseServiceImpl implements CourseService {
    @Autowired
    private CourseMapper courseMapper;
    @Autowired
    private CourseandstudentService courseandstudentService;

    public List<Course> findAll() {
        return courseMapper.selectByExample(null);
    }

    public Course findById(Integer id) {
        return courseMapper.selectByPrimaryKey(id);
    }

    public int updateById(Course course) {
        return courseMapper.updateByPrimaryKey(course);
    }

    public int insertById(Course course) {
        return courseMapper.insert(course);
    }

    @Override
    public List<Course> findAllByTeacher(Integer teacherid) {
        CourseExample example=new CourseExample();
        example.createCriteria().andTeacheridEqualTo(teacherid);
        List<Course> courses = courseMapper.selectByExample(example);
        return courses;
    }
    @Override
    public List<Course> findAll(Student student) {
        System.out.println("public List<Course> findAll(Student student) .....................");
        List<Courseandstudent> courseandstudents=courseandstudentService.findAllByStudent(student.getId());
        System.out.println(courseandstudents);
        ArrayList<Course> courses = new ArrayList<>();
        List<Course> all = findAll();
        A:for (Course course : all) {
            for (Courseandstudent courseandstudent : courseandstudents) {
                if (course.getId().equals(courseandstudent.getCourseid())){
                    continue A;
                }
            }
            courses.add(course);
        }
        return courses;
    }

    public int deleteById(Integer id) {
        return courseMapper.deleteByPrimaryKey(id);
    }
}
