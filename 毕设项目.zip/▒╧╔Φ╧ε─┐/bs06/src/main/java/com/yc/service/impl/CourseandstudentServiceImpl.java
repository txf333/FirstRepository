package com.yc.service.impl;

import java.util.List;

import com.yc.beans.Course;
import com.yc.beans.CourseExample;
import com.yc.beans.CourseandstudentExample;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yc.beans.Courseandstudent;
import com.yc.mapper.*;
import com.yc.service.CourseandstudentService;

@Service
public class CourseandstudentServiceImpl implements CourseandstudentService {
    @Autowired
    private CourseandstudentMapper courseandstudentMapper;


    public List<Courseandstudent> findAllByStudent(Integer studentid){
        CourseandstudentExample example=new CourseandstudentExample();
        example.createCriteria().andStudentidEqualTo(studentid);
        return  courseandstudentMapper.selectByExample(example);
    }



    @Override
    public List<Courseandstudent> findAll(CourseandstudentExample courseandstudentExample) {
        return courseandstudentMapper.selectByExample(courseandstudentExample);
    }

    public Courseandstudent findById(Integer id) {
        return courseandstudentMapper.selectByPrimaryKey(id);
    }

    public int updateById(Courseandstudent courseandstudent) {
        return courseandstudentMapper.updateByPrimaryKey(courseandstudent);
    }

    public int insertById(Courseandstudent courseandstudent) {
        return courseandstudentMapper.insert(courseandstudent);
    }

    public int deleteById(Integer id) {
        return courseandstudentMapper.deleteByPrimaryKey(id);
    }
}
