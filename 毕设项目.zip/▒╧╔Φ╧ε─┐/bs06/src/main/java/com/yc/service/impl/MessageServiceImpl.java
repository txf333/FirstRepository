package com.yc.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yc.beans.Message;
import com.yc.mapper.*;
import com.yc.service.MessageService;
@Service
public class MessageServiceImpl implements MessageService{
@Autowired
private MessageMapper messageMapper;
public List<Message> findAll() {
return messageMapper.selectByExample(null);
}
public Message findById(Integer id) {
return messageMapper.selectByPrimaryKey(id);
}
public int updateById(Message message) {
return messageMapper.updateByPrimaryKey(message);
}
public int insertById(Message message) {
return messageMapper.insert(message);
}
public int deleteById(Integer id) {
return messageMapper.deleteByPrimaryKey(id);
}
}
