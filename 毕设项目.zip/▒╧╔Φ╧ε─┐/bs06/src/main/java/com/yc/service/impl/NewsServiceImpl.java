package com.yc.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yc.beans.News;
import com.yc.mapper.*;
import com.yc.service.NewsService;
@Service
public class NewsServiceImpl implements NewsService{
@Autowired
private NewsMapper newsMapper;
public List<News> findAll() {
return newsMapper.selectByExample(null);
}
public News findById(Integer id) {
return newsMapper.selectByPrimaryKey(id);
}
public int updateById(News news) {
return newsMapper.updateByPrimaryKey(news);
}
public int insertById(News news) {
return newsMapper.insert(news);
}
public int deleteById(Integer id) {
return newsMapper.deleteByPrimaryKey(id);
}
}
