package com.yc.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yc.beans.Notice;
import com.yc.mapper.*;
import com.yc.service.NoticeService;
@Service
public class NoticeServiceImpl implements NoticeService{
@Autowired
private NoticeMapper noticeMapper;
public List<Notice> findAll() {
return noticeMapper.selectByExample(null);
}
public Notice findById(Integer id) {
return noticeMapper.selectByPrimaryKey(id);
}
public int updateById(Notice notice) {
return noticeMapper.updateByPrimaryKey(notice);
}
public int insertById(Notice notice) {
return noticeMapper.insert(notice);
}
public int deleteById(Integer id) {
return noticeMapper.deleteByPrimaryKey(id);
}
}
