package com.yc.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yc.beans.Resofcourse;
import com.yc.mapper.*;
import com.yc.service.ResofcourseService;
@Service
public class ResofcourseServiceImpl implements ResofcourseService{
@Autowired
private ResofcourseMapper resofcourseMapper;
public List<Resofcourse> findAll() {
return resofcourseMapper.selectByExample(null);
}
public Resofcourse findById(Integer id) {
return resofcourseMapper.selectByPrimaryKey(id);
}
public int updateById(Resofcourse resofcourse) {
return resofcourseMapper.updateByPrimaryKey(resofcourse);
}
public int insertById(Resofcourse resofcourse) {
return resofcourseMapper.insert(resofcourse);
}
public int deleteById(Integer id) {
return resofcourseMapper.deleteByPrimaryKey(id);
}
}
