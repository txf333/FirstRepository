package com.yc.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yc.beans.Student;
import com.yc.mapper.*;
import com.yc.service.StudentService;
@Service
public class StudentServiceImpl implements StudentService{
@Autowired
private StudentMapper studentMapper;
public List<Student> findAll() {
return studentMapper.selectByExample(null);
}
public Student findById(Integer id) {
return studentMapper.selectByPrimaryKey(id);
}
public int updateById(Student student) {
return studentMapper.updateByPrimaryKey(student);
}
public int insertById(Student student) {
return studentMapper.insert(student);
}
public int deleteById(Integer id) {
return studentMapper.deleteByPrimaryKey(id);
}
}
