package com.yc.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yc.beans.Teacher;
import com.yc.mapper.*;
import com.yc.service.TeacherService;
@Service
public class TeacherServiceImpl implements TeacherService{
@Autowired
private TeacherMapper teacherMapper;
public List<Teacher> findAll() {
return teacherMapper.selectByExample(null);
}
public Teacher findById(Integer id) {
return teacherMapper.selectByPrimaryKey(id);
}
public int updateById(Teacher teacher) {
return teacherMapper.updateByPrimaryKey(teacher);
}
public int insertById(Teacher teacher) {
return teacherMapper.insert(teacher);
}
public int deleteById(Integer id) {
return teacherMapper.deleteByPrimaryKey(id);
}
}
