package com.yc.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yc.beans.Work;
import com.yc.mapper.*;
import com.yc.service.WorkService;
@Service
public class WorkServiceImpl implements WorkService{
@Autowired
private WorkMapper workMapper;
public List<Work> findAll() {
return workMapper.selectByExample(null);
}
public Work findById(Integer id) {
return workMapper.selectByPrimaryKey(id);
}
public int updateById(Work work) {
return workMapper.updateByPrimaryKey(work);
}
public int insertById(Work work) {
return workMapper.insert(work);
}
public int deleteById(Integer id) {
return workMapper.deleteByPrimaryKey(id);
}
}
