package com.yc;

import com.yc.beans.Student;
import com.yc.service.StudentService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootTest
class Bs06ApplicationTests {

    @Autowired
    BCryptPasswordEncoder encoder;
    @Autowired
    StudentService studentService;
    @Test
    void contextLoads() {
        Student student = new Student();
        student.setUsername("zs");
        student.setPassword(encoder.encode("zs"));
        studentService.insertById(student);


    }

}
